const loginApi = "http://localhost:4500/user/login";

const loginForm = document.getElementById("login-form");
const loginButton = document.getElementById("login-button");
const message = document.getElementById("message");

loginForm.addEventListener("submit", async (event) => {
  event.preventDefault();

  message.innerText = "";

  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;

  loginButton.disabled = true;
  loginButton.innerText = "Logging in...";

  try {
    console.log("Calling login API...");

    const response = await axios.post(loginApi, {
      email,
      password,
    });

    console.log("Login response:", response.data);

    // Check your actual backend response
    const token = response.data.data?.token;

    if (!token) {
      throw new Error("Token not found in login response");
    }

    localStorage.setItem("token", token);

    console.log("Token saved");

    window.location.href = "/share-recipe/share-recipe.html";
  } catch (error) {
    console.log("Login error:", error);

    if (error.response) {
      console.log("Server response:", error.response.data);

      message.innerText = error.response.data?.message || "Login failed";
    } else if (error.request) {
      console.log("Request:", error.request);

      message.innerText = "Could not reach the server. Please try again.";
    } else {
      message.innerText = error.message || "Something went wrong.";
    }
  } finally {
    loginButton.disabled = false;
    loginButton.innerText = "Login";
  }
});
